# `slop theme import`

Replace the palette with a theme file made for this template

## Usage

```
slop theme import <document> <file> [options]
```

## Arguments

| Argument | Type | Required | Description |
| -------- | ---- | -------- | ----------- |
| `document` | string | Yes | Path to a .slop document |
| `file` | string | Yes | Theme file to import |

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `-h`, `--help` | boolean | No | Show help |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop theme`](../theme.md)

[Skill Overview](../../SKILL.md)
