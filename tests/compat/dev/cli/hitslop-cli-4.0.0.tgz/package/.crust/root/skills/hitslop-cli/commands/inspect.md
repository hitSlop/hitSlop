# `slop inspect`

Print what a .slop file holds: its kind, app, artwork, attachments and saved state sizes

## Usage

```
slop inspect <file> [options]
```

## Arguments

| Argument | Type | Required | Description |
| -------- | ---- | -------- | ----------- |
| `file` | string | Yes | Path to a .slop template or document |

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `-h`, `--help` | boolean | No | Show help |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
