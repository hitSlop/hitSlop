# `slop export`

Export a document as PNG or PDF on macOS

## Capture behavior
Open documents export their live selected view; closed documents export the saved state with the initial view. Output must not be the document itself. A lost acknowledgement has an uncertain outcome: inspect the destination before retrying.

## Usage

```
slop export <document> [options]
```

## Arguments

| Argument | Type | Required | Description |
| -------- | ---- | -------- | ----------- |
| `document` | string | Yes | Path to a .slop document |

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `--format` | string | Yes | Export format: png or pdf `[choices: png, pdf]` |
| `-h`, `--help` | boolean | No | Show help |
| `--output` | string | Yes | Destination file |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
