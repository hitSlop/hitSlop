---
name: hitslop-cli
description: Author hitSlop mini apps and work with local documents
metadata:
  version: "4.0.0"
---

# hitslop-cli

Author hitSlop mini apps and work with local documents

You should use this skill when you need accurate help with `hitslop-cli` commands, including command selection, syntax, arguments, flags, defaults, and subcommands.

## How to Use This Skill

1. You must find the command that best matches the user's task from the Command Reference below.
2. You must check the `Type` column before suggesting execution: `runnable` and `runnable, group` commands can be executed, while `group` commands are organizational only.
3. You should read only the linked file or files you need from `commands/`.
4. You must read a command's file before answering a command-specific question or suggesting that command.
5. You must treat the command file as the source of truth for usage, arguments, flags, aliases, and defaults.
6. If a flag, argument, alias, or default is not documented there, you must say it is not documented instead of guessing.

## Command Reference

You should use this table to locate the command file you need.

| Command | Type | Description | Documentation |
| ------- | ---- | ----------- | ------------- |
| `slop` | group | Author hitSlop mini apps and work with local documents | [commands/slop.md](commands/slop.md) |
| `slop apply` | runnable | Apply one document operation | [commands/apply.md](commands/apply.md) |
| `slop attachments` | group | Import, inspect, and export document attachments | [commands/attachments.md](commands/attachments.md) |
| `slop attachments export` | runnable | Export an attachment without overwriting an existing file | [commands/attachments/export.md](commands/attachments/export.md) |
| `slop attachments import` | runnable | Save a file and print its reference as JSON | [commands/attachments/import.md](commands/attachments/import.md) |
| `slop attachments list` | runnable | List attachment IDs and sizes | [commands/attachments/list.md](commands/attachments/list.md) |
| `slop batch` | runnable | Apply an atomic batch of document operations | [commands/batch.md](commands/batch.md) |
| `slop build` | runnable | Build a runtime template with native previews | [commands/build.md](commands/build.md) |
| `slop check` | runnable | Check Svelte and TypeScript authoring source | [commands/check.md](commands/check.md) |
| `slop compact` | runnable | Checkpoint document storage | [commands/compact.md](commands/compact.md) |
| `slop create` | runnable | Create a writable document from a built or registered template | [commands/create.md](commands/create.md) |
| `slop dev` | runnable | Serve a disposable browser preview | [commands/dev.md](commands/dev.md) |
| `slop export` | runnable | Export a document as PNG or PDF on macOS | [commands/export.md](commands/export.md) |
| `slop get` | runnable | Print current document state as JSON | [commands/get.md](commands/get.md) |
| `slop import` | runnable | Replace document data with a JSON file's value, writing only the differences | [commands/import.md](commands/import.md) |
| `slop init` | runnable | Create an authoring project from the checklist starter | [commands/init.md](commands/init.md) |
| `slop open` | runnable | Open a document in the hitSlop app | [commands/open.md](commands/open.md) |
| `slop register` | runnable | Build and register an immutable local template | [commands/register.md](commands/register.md) |
| `slop schema` | runnable | Print the document schema descriptor | [commands/schema.md](commands/schema.md) |
| `slop skills` | runnable, group | Manage agent skill installations (shorthand for `install`) | [commands/skills.md](commands/skills.md) |
| `slop skills install` | runnable | Link packaged skills into agent directories; never removes existing links | [commands/skills/install.md](commands/skills/install.md) |
| `slop skills repair` | runnable | Repair installed skill links | [commands/skills/repair.md](commands/skills/repair.md) |
| `slop skills uninstall` | runnable | Remove installed skill links | [commands/skills/uninstall.md](commands/skills/uninstall.md) |
| `slop theme` | group | Inspect, override and share a document's palette | [commands/theme.md](commands/theme.md) |
| `slop theme export` | runnable | Print or write the full palette as a theme file | [commands/theme/export.md](commands/theme/export.md) |
| `slop theme get` | runnable | Print the palette: template colors, overrides and effective colors | [commands/theme/get.md](commands/theme/get.md) |
| `slop theme import` | runnable | Replace the palette with a theme file made for this template | [commands/theme/import.md](commands/theme/import.md) |
| `slop theme reset` | runnable | Return one color, or every color, to the template's | [commands/theme/reset.md](commands/theme/reset.md) |
| `slop theme set` | runnable | Override declared theme colors | [commands/theme/set.md](commands/theme/set.md) |
