# `slop skills install`

Link packaged skills into agent directories; never removes existing links

## Usage

```
slop skills install [options]
```

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `--all`, `--no-all` | boolean | No | Install for every detected agent and every agent already holding a packaged skill, non-interactively |
| `-h`, `--help` | boolean | No | Show help |
| `--scope` | string | No | Skill scope (project or global) |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop skills`](../skills.md)

[Skill Overview](../../SKILL.md)
