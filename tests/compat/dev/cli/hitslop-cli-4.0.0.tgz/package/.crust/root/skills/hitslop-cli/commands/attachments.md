# `slop attachments`

Import, inspect, and export document attachments

## Subcommands

- [`export`](attachments/export.md) - Export an attachment without overwriting an existing file
- [`import`](attachments/import.md) - Save a file and print its reference as JSON
- [`list`](attachments/list.md) - List attachment IDs and sizes

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
