# `slop init`

Create an authoring project from the checklist starter

## Build with your agent
Interactive setup asks what your slop should do and saves it in BRIEF.md. After creation, choose a detected agent CLI, Other CLI to enter an executable and its prompt option, or Finish without launching. The agent starts in the project with BRIEF.md, AGENTS.md, and local hitSlop guidance, using its normal permissions. Launch failure keeps the project. --yes, CI, and non-TTY runs never prompt or launch another agent.

## Project metadata
Interactive terminals also ask for the author. Title, categories, and description start as the directory name, productivity, and A hitSlop mini app.; the launched agent updates them in manifest.json to match what it builds, and you can edit them there anytime. Flags set any of these explicitly; --category accepts one or two distinct values. An omitted brief uses the description. The slug is derived from the directory name unless --slug is supplied. All metadata is validated before creating files; existing destinations are refused. Project agent guides are portable copies, not links managed by skills repair.

## Usage

```
slop init <source> [options]
```

## Arguments

| Argument | Type | Required | Description |
| -------- | ---- | -------- | ----------- |
| `source` | string | Yes | Authoring source directory |

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `--author` | string | No | Author name (default: Anonymous) |
| `--brief` | string | No | What the slop should do; saved in BRIEF.md for your agent |
| `--category` | string | No | Catalog category; repeat for a second category. Can be specified multiple times |
| `--description` | string | No | App description (default: A hitSlop mini app.) |
| `-h`, `--help` | boolean | No | Show help |
| `--slug` | string | No | App slug: 2–64 lowercase letters/digits with single hyphens |
| `--title` | string | No | App title (defaults to directory name) |
| `--yes`, `--no-yes` | boolean | No | Skip prompts and agent launch; use defaults for missing metadata |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
