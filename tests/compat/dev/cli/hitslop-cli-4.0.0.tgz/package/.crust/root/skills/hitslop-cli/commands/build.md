# `slop build`

Build a runtime template on any platform

## Usage

```
slop build <source> [options]
```

## Arguments

| Argument | Type | Required | Description |
| -------- | ---- | -------- | ----------- |
| `source` | string | Yes | Authoring source directory |

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `--artwork` | string | No | native: render Finder artwork not in artwork/ with hitSlop.app (macOS) |
| `-h`, `--help` | boolean | No | Show help |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
