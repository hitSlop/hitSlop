# `slop skills uninstall`

Remove installed skill links

## Usage

```
slop skills uninstall [options]
```

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `--all`, `--no-all` | boolean | No | Uninstall every installed skill non-interactively |
| `-h`, `--help` | boolean | No | Show help |
| `--scope` | string | No | Skill scope (project or global) `[choices: project, global]` |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop skills`](../skills.md)

[Skill Overview](../../SKILL.md)
