# `slop batch`

Apply an atomic batch of document operations

## Retries
Mutations are never automatically replayed. After an unknown outcome, run slop get before issuing another edit. get saves and returns owner-accepted state; text still being typed in an open window is not included.

## Usage

```
slop batch <document> [options]
```

## Arguments

| Argument | Type | Required | Description |
| -------- | ---- | -------- | ----------- |
| `document` | string | Yes | Path to a .slop document |

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `--attach` | string | No | A file the operations reference, stored in the same batch; repeat for more. slop attachments ref prints its reference. A file nothing references is removed when the document closes. Can be specified multiple times |
| `--base` | string | No | The version you read (state.version from get --snapshot) or last wrote (a batch's version). Text sets then change the text as it was at that version and keep edits made since, such as typing in an open window |
| `-h`, `--help` | boolean | No | Show help |
| `--ops` | string | Yes | Array of operations as JSON |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
