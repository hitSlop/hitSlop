# `slop attachments list`

List attachment IDs and sizes

## Usage

```
slop attachments list <document> [options]
```

## Arguments

| Argument | Type | Required | Description |
| -------- | ---- | -------- | ----------- |
| `document` | string | Yes | Path to a .slop document |

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `-h`, `--help` | boolean | No | Show help |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop attachments`](../attachments.md)

[Skill Overview](../../SKILL.md)
