# `slop skills`

Manage agent skill installations (shorthand for `install`)

## Usage

```
slop skills [options]
```

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `--all`, `--no-all` | boolean | No | Install for every detected agent and every agent already holding a packaged skill, non-interactively |
| `-h`, `--help` | boolean | No | Show help |
| `--scope` | string | No | Skill scope (project or global) `[choices: project, global]` |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

## Subcommands

- [`install`](skills/install.md) - Link packaged skills into agent directories; never removes existing links
- [`repair`](skills/repair.md) - Repair installed skill links
- [`uninstall`](skills/uninstall.md) - Remove installed skill links

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
