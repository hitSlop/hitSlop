# `slop apply`

Apply one document operation

## Retries
Mutations are never automatically replayed. After an unknown outcome, run slop get before issuing another edit. get saves and returns owner-accepted state; text still being typed in an open window is not included.

## Usage

```
slop apply <document> [options]
```

## Arguments

| Argument | Type | Required | Description |
| -------- | ---- | -------- | ----------- |
| `document` | string | Yes | Path to a .slop document |

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `-h`, `--help` | boolean | No | Show help |
| `--op` | string | Yes | Operation object as JSON |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
