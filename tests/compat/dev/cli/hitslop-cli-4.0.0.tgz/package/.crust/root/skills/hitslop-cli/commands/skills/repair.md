# `slop skills repair`

Repair installed skill links

## Usage

```
slop skills repair [options]
```

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `-h`, `--help` | boolean | No | Show help |
| `--scope` | string | No | Skill scope (project or global) `[choices: project, global]` |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop skills`](../skills.md)

[Skill Overview](../../SKILL.md)
