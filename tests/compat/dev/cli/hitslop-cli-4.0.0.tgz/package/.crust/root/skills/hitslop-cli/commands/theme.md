# `slop theme`

Inspect, override and share a document's palette

## Subcommands

- [`export`](theme/export.md) - Print or write the full palette as a theme file
- [`get`](theme/get.md) - Print the palette: template colors, overrides and effective colors
- [`import`](theme/import.md) - Replace the palette with a theme file made for this template
- [`reset`](theme/reset.md) - Return one color, or every color, to the template's
- [`set`](theme/set.md) - Override declared theme colors

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
