# `slop import`

Replace document data with a JSON file's value, writing only the differences

## Retries
Mutations are never automatically replayed. After an unknown outcome, run slop get before issuing another edit. get saves and returns owner-accepted state; text still being typed in an open window is not included.

## Usage

```
slop import <document> <file> [options]
```

## Arguments

| Argument | Type | Required | Description |
| -------- | ---- | -------- | ----------- |
| `document` | string | Yes | Path to a .slop document |
| `file` | string | Yes | JSON file holding the new value |

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `-h`, `--help` | boolean | No | Show help |
| `--path` | string | No | Where to replace, as a JSON path (default: the whole document), e.g. '["rows"]' |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
