# `slop theme set`

Override declared theme colors

## Usage

```
slop theme set <document> [options]
```

## Arguments

| Argument | Type | Required | Description |
| -------- | ---- | -------- | ----------- |
| `document` | string | Yes | Path to a .slop document |

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `-h`, `--help` | boolean | No | Show help |
| `--values` | string | Yes | Colors as JSON, such as {"accent":"#335577"} |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop theme`](../theme.md)

[Skill Overview](../../SKILL.md)
