# `slop`

Author hitSlop mini apps and work with local documents

## Document workflow
Run bunx @hitslop/cli or install globally with bun install -g @hitslop/cli. Read slop.ts first. Inspect schema before editing. Built and registered template masters are immutable: create a writable copy before editing. Native macOS commands route to the live session or acquire exclusive ownership when closed.

## Subcommands

- [`apply`](apply.md) - Apply one document operation
- [`attachments`](attachments.md) - Import, inspect, and export document attachments
- [`batch`](batch.md) - Apply an atomic batch of document operations
- [`build`](build.md) - Build a runtime template on any platform
- [`check`](check.md) - Check Svelte and TypeScript authoring source, and slop.ts as a build does
- [`create`](create.md) - Create a writable document from a built or registered template
- [`dev`](dev.md) - Serve a disposable browser preview
- [`export`](export.md) - Export a document as PNG or PDF on macOS
- [`get`](get.md) - Print current document state as JSON
- [`import`](import.md) - Replace document data with a JSON file's value, writing only the differences
- [`init`](init.md) - Create an authoring project from the checklist starter
- [`inspect`](inspect.md) - Print what a .slop file holds: its kind, app, artwork, attachments and saved state sizes
- [`open`](open.md) - Open a document in the hitSlop app
- [`register`](register.md) - Build with native artwork and register an immutable local template (macOS)
- [`schema`](schema.md) - Print the document schema descriptor
- [`skills`](skills.md) - Manage agent skill installations (shorthand for `install`)
- [`theme`](theme.md) - Inspect, override and share a document's palette

---

[Skill Overview](../SKILL.md)
