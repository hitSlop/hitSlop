# `slop get`

Print current document state as JSON

## Usage

```
slop get <document> [options]
```

## Arguments

| Argument | Type | Required | Description |
| -------- | ---- | -------- | ----------- |
| `document` | string | Yes | Path to a .slop document |

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `-h`, `--help` | boolean | No | Show help |
| `--snapshot`, `--no-snapshot` | boolean | No | Print the schema with the current state ({schema, state}) |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
