/* tslint:disable */
/* eslint-disable */

/**
 * Mirrors the native `ApplyResult` record.
 */
export class ApplyResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    ids: string[];
    get publication(): string | undefined;
    set publication(value: string | null | undefined);
    sequence: number;
}

/**
 * Mirrors the native `TextResult` record.
 */
export class TextResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    authored: string;
    get publication(): string | undefined;
    set publication(value: string | null | undefined);
    selectionEnd: number;
    selectionStart: number;
    sequence: number;
}

export class WasmDocument {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * A page's batch, part of the person's undo.
     */
    applyBatch(batch_json: string): ApplyResult;
    static create(schema_json: string, initial_json: string): WasmDocument;
    static createWithTheme(schema_json: string, initial_json: string, template: string, defaults_json: string): WasmDocument;
    editText(request_json: string): TextResult;
    redo(): ApplyResult;
    /**
     * The full recomputation that `state` is tested against.
     */
    snapshot(): string;
    /**
     * The owner's current state, as a page opens it.
     */
    state(): string;
    themeSet(values_json: string): ApplyResult;
    undo(): ApplyResult;
}

export function coreBuildId(): string;

export function validate(schema_json: string, initial_json: string): void;

export function validateThemeDefaults(json: string): void;

/**
 * Validates a manifest window `shape` (JSON, or undefined for the default).
 */
export function validateWindowShape(shape_json: string | null | undefined, width: number, height: number): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_applyresult_free: (a: number, b: number) => void;
    readonly __wbg_get_applyresult_ids: (a: number) => [number, number];
    readonly __wbg_get_applyresult_publication: (a: number) => [number, number];
    readonly __wbg_get_applyresult_sequence: (a: number) => number;
    readonly __wbg_get_textresult_authored: (a: number) => [number, number];
    readonly __wbg_get_textresult_selectionEnd: (a: number) => number;
    readonly __wbg_get_textresult_selectionStart: (a: number) => number;
    readonly __wbg_set_applyresult_ids: (a: number, b: number, c: number) => void;
    readonly __wbg_set_applyresult_publication: (a: number, b: number, c: number) => void;
    readonly __wbg_set_applyresult_sequence: (a: number, b: number) => void;
    readonly __wbg_set_textresult_authored: (a: number, b: number, c: number) => void;
    readonly __wbg_set_textresult_selectionEnd: (a: number, b: number) => void;
    readonly __wbg_set_textresult_selectionStart: (a: number, b: number) => void;
    readonly __wbg_textresult_free: (a: number, b: number) => void;
    readonly __wbg_wasmdocument_free: (a: number, b: number) => void;
    readonly coreBuildId: () => [number, number];
    readonly validate: (a: number, b: number, c: number, d: number) => [number, number];
    readonly validateThemeDefaults: (a: number, b: number) => [number, number];
    readonly validateWindowShape: (a: number, b: number, c: number, d: number) => [number, number];
    readonly wasmdocument_applyBatch: (a: number, b: number, c: number) => [number, number, number];
    readonly wasmdocument_create: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly wasmdocument_createWithTheme: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly wasmdocument_editText: (a: number, b: number, c: number) => [number, number, number];
    readonly wasmdocument_redo: (a: number) => [number, number, number];
    readonly wasmdocument_snapshot: (a: number) => [number, number, number, number];
    readonly wasmdocument_state: (a: number) => [number, number, number, number];
    readonly wasmdocument_themeSet: (a: number, b: number, c: number) => [number, number, number];
    readonly wasmdocument_undo: (a: number) => [number, number, number];
    readonly __wbg_get_textresult_sequence: (a: number) => number;
    readonly __wbg_set_textresult_sequence: (a: number, b: number) => void;
    readonly __wbg_set_textresult_publication: (a: number, b: number, c: number) => void;
    readonly __wbg_get_textresult_publication: (a: number) => [number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
