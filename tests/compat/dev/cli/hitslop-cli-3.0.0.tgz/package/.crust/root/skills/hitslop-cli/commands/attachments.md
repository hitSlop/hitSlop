# `slop attachments`

Reference, inspect, and export document attachments

## Subcommands

- [`export`](attachments/export.md) - Export an attachment without overwriting an existing file
- [`list`](attachments/list.md) - List attachment IDs and sizes
- [`ref`](attachments/ref.md) - Print a file's reference as JSON, for operations that store it with --attach

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
