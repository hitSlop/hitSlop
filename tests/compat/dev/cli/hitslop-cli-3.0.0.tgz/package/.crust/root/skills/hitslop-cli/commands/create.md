# `slop create`

Create a writable document from a built or registered template

## Usage

```
slop create [options]
```

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `--from` | string | Yes | Template .slop to copy |
| `-h`, `--help` | boolean | No | Show help |
| `--output` | string | Yes | Path for the new writable document; .slop is added if it is missing |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop`](slop.md)

[Skill Overview](../SKILL.md)
