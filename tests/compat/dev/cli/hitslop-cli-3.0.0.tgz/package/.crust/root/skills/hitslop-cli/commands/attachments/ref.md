# `slop attachments ref`

Print a file's reference as JSON, for operations that store it with --attach

## Usage

```
slop attachments ref <file> [options]
```

## Arguments

| Argument | Type | Required | Description |
| -------- | ---- | -------- | ----------- |
| `file` | string | Yes | - |

## Flags

| Flag | Type | Required | Description |
| ---- | ---- | -------- | ----------- |
| `-h`, `--help` | boolean | No | Show help |

## Command Documentation Authority

You must treat only the arguments, flags, options, aliases, and defaults documented in this file as supported for this command.
You must not infer or invent additional command-line options.

---

Parent: [`slop attachments`](../attachments.md)

[Skill Overview](../../SKILL.md)
